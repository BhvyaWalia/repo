package com.example.w22comp1011gctest2student;

public class Product {
  }
